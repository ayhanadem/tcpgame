import java.util.Scanner;


public class Main
{

	public static void main(String[] args)
	{

		Scanner scan = new Scanner(System.in);
		
		
		System.out.println("Yeni Oyun (Y) / Mevcut Oyun (M)");
		String s =scan.next();
		
		if(s.equals("Y"))
		{
			Server server = new Server();
			server.start();
			
			Client client  = new Client();
			
			client.start();
			
		}
		else
		{
			Client client = new Client();
			client.start();
		}

	}

}
