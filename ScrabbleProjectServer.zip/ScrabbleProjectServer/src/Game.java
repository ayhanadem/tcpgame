import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class Game
{

	Queue<ClientHandler> clients;
	String[][] board;
	int playCount=0;

	public Game(int size)
	{
		this.board = new String[size][size];

		for (int i = 0; i < board.length; i++)
		{
			for (int j = 0; j < board.length; j++)
			{
				board[i][j] = "_";
			}

		}

		this.clients = new LinkedList<ClientHandler>();
	}

	public boolean addClient(ClientHandler client)
	{
		checkClients();
		if (clients.size() < 4)
		{

			clients.add(client);
			return true;
		}
		else
		{
			return false;
		}

	}

	private void checkClients()
	{
		if (this.clients.size() > 0)
		{
			for (Iterator<ClientHandler> iterator = clients.iterator(); iterator
					.hasNext();)
			{
				ClientHandler clientHandler = (ClientHandler) iterator.next();

				if (!clientHandler.isAlive())
				{
					iterator.remove();
				}
			}
		}
	}

	public String play(ClientHandler client, String text)
	{

		// Deneme#4#5#0

		String[] commands = text.split("#");

		String word = commands[0];
		int row = Integer.valueOf(commands[1]);
		int column = Integer.valueOf(commands[2]);
		int rightOrDown = Integer.valueOf(commands[3]);

		String resultText = "";
		if (!clients.isEmpty())
		{
			if (!clients.peek().isAlive())
			{
				clients.remove();
			}
			if (clients.peek().id == client.id)
			{

				if (isMoveOk(word, row, column, rightOrDown))
				{
					resultText = "Client No : " + client.id + " - " + text;
					
					//resultText = resultText + "\n" + getBoardString();
					playCount++;
					clients.add(clients.remove());
				}
				else
				{
					resultText = "Client No : " + client.id + " - Yanl�� Hamle";
				}

			}
			else
			{
				resultText = "Client No : " + client.id
						+ " S�ran gelmedi bekle";
			}
		}
		else
		{
			resultText = "Kuyrukta Client Yok";
		}

		// System.out.println(resultText);

		return resultText;

	}

	private boolean isMoveOk(String word, int row, int column, int rightOrDown)
	{
		try
		{
			int size = board.length;

			if (rightOrDown == 0)
			{
				if (size <= (column + word.length()))
				{
					return false;
				}
				else
				{
					int counter = 0;
					for (int i = 0; i < word.length(); i++)
					{
						if (!board[row][column + i].equals("_")
								&& !board[row][column + i].equals(String
										.valueOf(word.charAt(i))))
						{
							return false;
						}
						else if (board[row][column + i].equals(String
								.valueOf(word.charAt(i))))
						{
							counter++;
						}

					}

					if (counter < 1 && playCount>0)
					{
						return false;
					}
					for (int i = 0; i < word.length(); i++)
					{

						board[row][column + i] = String.valueOf(word.charAt(i));
					}
				}
			}
			else
			{
				if (size <= (row + word.length()))
				{
					return false;
				}
				else
				{
					int counter = 0;
					for (int i = 0; i < word.length(); i++)
					{
						if (!board[row + i][column].equals("_")
								&& !board[row + i][column].equals(String
										.valueOf(word.charAt(i))))
						{
							return false;
						}
						else if (board[row + i][column].equals(String
								.valueOf(word.charAt(i))))
						{
							counter++;
						}

					}

					if (counter < 1 && playCount>0)
					{
						return false;
					}

					for (int i = 0; i < word.length(); i++)
					{
						board[row + i][column] = String.valueOf(word.charAt(i));
					}
				}
			}

			return true;
		}
		catch (Exception e)
		{
			return false;
		}

	}

	public String getBoardString()
	{
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < board.length; i++)
		{
			for (int j = 0; j < board.length; j++)
			{
				sb.append(board[i][j]);
				sb.append(" ");
			}
			sb.append("\n");
		}

		return sb.toString();
	}

	public boolean checkUserName(String su)
	{
		if (this.clients.size() > 0)
		{
			for (Iterator<ClientHandler> iterator = clients.iterator(); iterator
					.hasNext();)
			{
				ClientHandler clientHandler = (ClientHandler) iterator.next();

				if (clientHandler.username != null && su.equalsIgnoreCase(clientHandler.username))
				{
					 return false;
				}
			}
		}
		
		return true;
	}
}
