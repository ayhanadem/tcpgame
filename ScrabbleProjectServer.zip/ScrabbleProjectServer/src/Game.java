import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class Game
{

	Queue<ClientHandler> clients;

	public Game()
	{

		this.clients = new LinkedList<ClientHandler>();
	}

	public boolean addClient(ClientHandler client)
	{
		checkClients();
		if (clients.size() < 4)
		{

			clients.add(client);
			return true;
		}
		else
		{
			return false;
		}

	}

	private void checkClients()
	{
		if (this.clients.size() > 0)
		{
			for (Iterator<ClientHandler> iterator = clients.iterator(); iterator.hasNext();)
			{
				ClientHandler clientHandler = (ClientHandler) iterator.next();

				if (!clientHandler.isAlive())
				{
					iterator.remove();
				}
			}
		}
	}

	public String play(ClientHandler client, String text)
	{
		String resultText = "";
		if (!clients.isEmpty())
		{
			if (!clients.peek().isAlive())
			{
				clients.remove();
			}
			if (clients.peek().id == client.id)
			{
				resultText = "Client No : " + client.id + " - " + text;
				clients.add(clients.remove());
			}
			else
			{
				resultText = "Client No : " + client.id
						+ " S�ran gelmedi hayvan";
			}
		}
		else
		{
			resultText = "Kuyrukta Client Yok";
		}

		System.out.println(resultText);

		return resultText;

	}
}
