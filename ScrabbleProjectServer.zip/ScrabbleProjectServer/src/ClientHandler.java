import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ClientHandler extends Thread
{

	final DataInputStream dis;
	final DataOutputStream dos;
	final Socket s;
	public Game game;
	public int id;

	// Constructor
	public ClientHandler(Game game, Socket s, DataInputStream dis,
			DataOutputStream dos, int id)
	{
		this.game = game;
		this.s = s;
		this.dis = dis;
		this.dos = dos;
		this.id = id;
	}

	@Override
	public void run()
	{
		String received;
		boolean runable = true;
		while (runable)
		{
			try
			{
				dos.writeUTF("Kelime Girin\n");
				received = dis.readUTF();
				if (received.equals("Exit"))
				{
					System.out.println("Client " + this.id + " ��k�yor...");
					System.out.println("Ba�lant� kapat�l�yor.");
					this.s.close();
					System.out.println("Ba�lant� kapat�ld�");
				}
				else
				{

					String resText = this.game.play(this, received);
					dos.writeUTF(resText);
				}

			}
			catch (IOException e)
			{
				e.printStackTrace();
				runable = false;
			}
			catch (Exception e)
			{
				runable = false;
			}
		}

		try
		{
			this.dis.close();
			this.dos.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}