import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ClientHandler extends Thread
{

	final DataInputStream dis;
	final DataOutputStream dos;
	final Socket s;
	public Game game;
	public int id;
	public String username;

	// Constructor
	public ClientHandler(Game game, Socket s, DataInputStream dis,
			DataOutputStream dos, int id)
	{
		this.game = game;
		this.s = s;
		this.dis = dis;
		this.dos = dos;
		this.id = id;
	}

	@Override
	public void run()
	{
		String received;
		boolean runable = true;
		while (runable)
		{
			try
			{
				dos.writeUTF("Kelime Girin\n" + game.getBoardString());
				received = dis.readUTF();
				if (received.equals("Exit"))
				{
					System.out.println("Client " + this.id + " ��k�yor...");
					System.out.println("Ba�lant� kapat�l�yor.");
					this.s.close();
					System.out.println("Ba�lant� kapat�ld�");
				}
				else if (received.equalsIgnoreCase("r"))
				{
					String resText = this.game.getBoardString();
					dos.writeUTF(resText);

				}
				else if (received.startsWith("username"))
				{
					String su = received.split("#")[1];
					if (game.checkUserName(su))
					{
						this.username = su;
						dos.writeUTF("username " + su + " kabul edilmi�tir");
					}
					else
					{
						dos.writeUTF("Ba�ka bir username se�iniz");
					}
				}
				else
				{
					
					try
					{
					String resText ="";
					if(this.username ==null)
					{
						resText = "Username belirlemeniz gerekmektedir. username#{username} �eklinde username belirleyiniz";
						dos.writeUTF(resText);
					}
					else
					{
						resText = this.game.play(this, received);
						dos.writeUTF(resText);
					}
					}
					catch(Exception e)
					{
						 
						dos.writeUTF("L�tfen hamlenizi {Kelime}#{Sat�r}#{Sutun}#{Sa�a0veyaA�a��1} �eklinde giriniz");
					}
					 
				}

			}
			catch (IOException e)
			{
				e.printStackTrace();
				runable = false;
			}
			catch (Exception e)
			{
				runable = false;
			}
		}

		try
		{
			this.dis.close();
			this.dos.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}