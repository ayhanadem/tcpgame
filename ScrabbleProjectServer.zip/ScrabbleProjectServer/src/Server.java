import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server extends Thread
{

	@Override
	public void run()
	{
		try
		{
			int port =5056;  //userdan al
			ServerSocket ss = new ServerSocket(port);
			int boardSize= 10; //userdan al
			Game game = new Game(boardSize);
			int counter = 0;

			while (true)
			{
				Socket s = null;

				try
				{
					s = ss.accept();

					System.out.println("Yeni Client Eklendi : " + s);

					DataInputStream dis = new DataInputStream(
							s.getInputStream());
					DataOutputStream dos = new DataOutputStream(
							s.getOutputStream());

					counter++;
					ClientHandler t = new ClientHandler(game, s, dis, dos,
							counter);

					if (game.addClient(t))
					{
						t.start();
					}
					else
					{
						s.close();
						System.out
								.println("Sistemde 4 tane client mevcut fazlas� eklenemez");
					}
				}
				catch (Exception e)
				{
					s.close();
					e.printStackTrace();
				}
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
